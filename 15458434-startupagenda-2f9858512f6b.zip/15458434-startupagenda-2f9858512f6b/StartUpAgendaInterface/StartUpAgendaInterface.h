//
//  StartUpAgendaInterface.h
//  StartUpAgendaInterface
//
//  Created by Mark Cornelisse on 13/07/15.
//  Copyright (c) 2015 Over de muur producties. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for StartUpAgendaInterface.
FOUNDATION_EXPORT double StartUpAgendaInterfaceVersionNumber;

//! Project version string for StartUpAgendaInterface.
FOUNDATION_EXPORT const unsigned char StartUpAgendaInterfaceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StartUpAgendaInterface/PublicHeader.h>


