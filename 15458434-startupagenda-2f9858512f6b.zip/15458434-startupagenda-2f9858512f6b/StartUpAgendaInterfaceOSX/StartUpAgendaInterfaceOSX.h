//
//  StartUpAgendaInterfaceOSX.h
//  StartUpAgendaInterfaceOSX
//
//  Created by Mark Cornelisse on 13/07/15.
//  Copyright (c) 2015 Over de muur producties. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for StartUpAgendaInterfaceOSX.
FOUNDATION_EXPORT double StartUpAgendaInterfaceOSXVersionNumber;

//! Project version string for StartUpAgendaInterfaceOSX.
FOUNDATION_EXPORT const unsigned char StartUpAgendaInterfaceOSXVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StartUpAgendaInterfaceOSX/PublicHeader.h>


